package busreser;
import java.util.Scanner;
import java.util.ArrayList;
class busdemo {
	public static void main (String[] args) {
		ArrayList<bus> busses = new ArrayList<bus>();
		ArrayList<booking> bookings = new ArrayList();
		busses.add(new bus(1,true,2));
		busses.add(new bus(2,true,35));
		busses.add(new bus(3,false,40));
		busses.add(new bus(4,true,32));
		busses.add(new bus(5,false,28));
	System.out.println("Enter 1 to Continue or 2 to Exit");
	Scanner sc = new Scanner(System.in);
	for(bus b:busses) {
		b.DisplayBusinfo();
	}
	int value = sc.nextInt();
//	switch(value){
//	case 1:System.out.println("lets move ahead for booking");
//	break;
//	case 2:System.out.println("hope u will reach us when u need booking,Thank you");
//	break;
//	default:System.out.println("please enter valid option");
	if (value == 1) {
		System.out.println("lets move ahead for booking");
		booking Booking = new booking();
		if (Booking.isAvailable(bookings,busses)) {
			bookings.add(Booking);
			System.out.println("Your Booking is Confirmed");
		}
		else
			System.out.println("Sorry, bus is full please try another date or bus");
	}
	}}