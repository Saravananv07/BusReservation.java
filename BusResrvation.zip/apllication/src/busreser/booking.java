package busreser;
import java.util.*;
import java.text.SimpleDateFormat;
public class booking {
	String passengerName;
	int busno;
	Date date;
	
	booking(){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name of passenger");
		passengerName = sc.next();
		System.out.println("Enter BusNo");
		busno = sc.nextInt();
		System.out.println("Ente date dd-MM-yyyy");
		String dateInput = sc.next();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		
//		try {
//			date = dateFormat.parse(dateInput);
//		} catch (ParseException e) {
//			e.printStackTrace();
//		}
	
	} 
	public boolean isAvailable(ArrayList<booking> bookings, ArrayList<bus> buses) {
		int capacity = 0;
		for(bus b:buses) {
			if(b.getbusno()== busno)
				capacity = b.getcapacity();
		}
		int booked =0 ;
		for(booking b:bookings) {
			if(b.busno==busno && b.date.equals(date)) {
				booked++;
			}
		}
		return booked<capacity?true:false;
		 
	}

}
