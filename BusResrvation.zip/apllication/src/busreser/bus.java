package busreser;
import java.util.*;

public class bus {
	private int busno;
	private boolean ac; 
	private int capacity;
	
	bus(int no,boolean ac,int cap){
		this.busno = no;
		this.ac =ac;
		this.capacity = cap;
		}
	//below 2 are about get nd set method where get is used to get the value and set is used to update existing value
	
	public int getbusno() {
		return busno;
	}
	public boolean isAc() {
		return ac;
	}
	public int getcapacity() {
		return capacity;
	}
	public void setBusno(int bno) {
		busno = bno;
	}
	public void setAc(boolean value) {
		ac = value;
	}
	public void setCapacity(int cap) {
		capacity = cap;
	}
	public void DisplayBusinfo() {
		System.out.println(" Bus no :" + busno+" AC :" + ac +" Capacity :" + capacity);
	}
	

}
